#ifndef head
#define head

//Cabeçalho de todas as funções utilizadas no main e funções usadas dentro das funções

void inicializar ();

void sortearbombas ();

int coordval (int l, int c);

int qntbombasvizinhas (int l, int c);

void contbombas ();

void imprimir ();

void abrir (int l, int c);

int ganha ();

void dica ();

void BOT();

void jogadas ();

#endif