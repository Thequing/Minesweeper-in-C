#ifndef user

#define user

void abrir(int l, int c);

int ganha();

void jogadas();

#endif