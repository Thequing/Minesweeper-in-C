#include <stdio.h>

#include <stdlib.h>

#include <time.h>

#include "head.h"

int main(void) {

  inicializar();
  
  sortearbombas();
  
  contbombas();
  
  jogadas();

  return 0;
}

