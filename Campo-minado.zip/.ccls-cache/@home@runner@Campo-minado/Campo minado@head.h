#ifndef head
#define head

void inicializar ();

void sortearbombas ();

int coordval (int l, int c);

int qntbombasvizinhas (int l, int c);

void contbombas ();

void imprimir ();

void abrir (int l, int c);

int ganha ();

void dica ();

void jogadas ();

#endif