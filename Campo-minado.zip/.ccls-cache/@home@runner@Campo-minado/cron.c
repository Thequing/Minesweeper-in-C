#include <time.h>

#include <stdio.h>

#include <unistd.h>

#include "cron.h"

void func_cronometro (cronometro tempo, int estado_jogo) {
  
  while (estado_jogo != 1) {
    
    if (tempo.seg == 60) {
      tempo.mins = tempo.mins + 1;
      tempo.seg = 0;
      }
    if (tempo.mins == 60) {
      tempo.horas = tempo.horas + 1;
      tempo.mins = 0;
      }
    if (tempo.horas == 24) {
      tempo.horas = 0;
      }
    sleep(1);
    tempo.seg = tempo.seg + 1;
  } printf (" Você fez em %d h. %d mins. %d seg\n", tempo.horas, tempo.mins, tempo.seg);
}

void crono (int estado_jogo) {
  cronometro tempo;
  tempo.seg = 0;
  tempo.mins = 0;
  tempo.horas = 0;
  
  func_cronometro(tempo, estado_jogo);
}  
