#include <stdio.h>

#include <stdlib.h>

#include <time.h>

typedef struct {
  int ebomba;
  int aberta;
  int vizinhos;
}
campo;

campo mat[10][20];
int l, c;

void imprimir() {
  printf("\n\n\t  ");
  for (l = 1; l <= 20; l++) {
    if (l < 10) {
      printf("   %d", l);
    } else {
      printf("  %d", l);
    }
  }
  printf("\n\t   --------------------------------------------------------------------------------- \n");
  for (l = 1; l <= 10; l++) {
    if (l < 10) {
      printf("\t%d  |", l);
      for (c = 1; c <= 20; c++) {
        if (mat[l][c].aberta) {
          if (mat[l][c].ebomba == 1) {
            printf(" * ");
          } else {
            printf(" %d ", mat[l][c].vizinhos);
          }
        } else {
          printf("   ");
        }
        printf("|");
      }
      printf("\n\t   --------------------------------------------------------------------------------- \n");
    } else {
      printf("\t%d |", l);
      for (c = 1; c <= 20; c++) {
        if (mat[l][c].aberta) {
          if (mat[l][c].ebomba == 1) {
            printf(" * ");
          } else {
            printf(" %d ", mat[l][c].vizinhos);
          }
        } else {
          printf("   ");
        }
        printf("|");
      }
      printf("\n\t   --------------------------------------------------------------------------------- \n");
    } 
  }
}