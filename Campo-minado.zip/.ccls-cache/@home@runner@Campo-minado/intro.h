#ifndef func
#define print

void inicializar();

void sortearbombas();







#endif