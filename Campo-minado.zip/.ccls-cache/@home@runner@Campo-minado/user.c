#include <stdio.h>

#include <stdlib.h>

#include <time.h>

typedef struct {
  int ebomba;
  int aberta;
  int vizinhos;
}
campo;

campo mat[10][20];
int l, c;

void abrir(int l, int c) {
  if (coordval(l, c) == 1 && mat[l][c].aberta == 0) {

    mat[l][c].aberta = 1;

    if (mat[l][c].vizinhos == 0) {
      abrir(l - 1, c);
      abrir(l + 1, c);
      abrir(l, c - 1);
      abrir(l, c + 1);
      abrir(l + 1, c + 1);
      abrir(l + 1, c - 1);
      abrir(l - 1, c + 1);
      abrir(l - 1, c - 1);
    }
  }
}

int ganha() {
  int qnt = 0;

  for (l = 1; l <= 10; l++) {
    for (c = 1; c <= 20; c++) {
      if (mat[l][c].aberta == 0 && mat[l][c].ebomba == 0) {
        qnt++;
      }
    }
  }
  return qnt;
}

void jogadas() {
  int lin, col;

  do {
    imprimir();
    do {
      printf("\nQual a sua jogada? (Lembrando que primero a linha, depois coluna, separados por um espaço): ");
      scanf("%d %d", & lin, & col);

      if (coordval(lin, col) == 0) {
        printf("\nEssa coordenada não pode...");
      }
    } while (coordval(lin, col) == 0 || mat[lin][col].aberta == 1);

    abrir(lin, col);
  } while (ganha() != 0 && mat[lin][col].ebomba == 0);

  if (mat[lin][col].ebomba == 1) {
    printf("\nOLHA A BOMBA!!!");
  } else {
    printf("\nOLHA, CONSEGUIU SAIR COM AS DUAS PERNAS, VOCÊ VENCEU!");
  }
}