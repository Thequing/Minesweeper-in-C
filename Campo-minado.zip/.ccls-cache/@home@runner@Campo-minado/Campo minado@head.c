#include <stdio.h>

#include <stdlib.h>

#include <time.h>

typedef struct {
  int ebomba;
  int aberta;
  int vizinhos;
}
campo;

campo mat[10][20];
int l, c;

void inicializar() {
  for (l = 1; l <= 10; l++) {
    for (c = 1; c <= 20; c++) {
      mat[l][c].ebomba = 0;
      mat[l][c].aberta = 0;
      mat[l][c].vizinhos = 0;
    }
  }
}

void sortearbombas() {
  int i;
  srand(time(NULL));
  for (i = 0; i < 40; i++) {
    l = rand() % 10;
    c = rand() % 20;
    if (mat[l][c].ebomba == 0) {
      mat[l][c].ebomba = 1;
    } else {
      i--;
    }
  }
}

int coordval(int l, int c) {
  if (l >= 1 && l <= 10 && c >= 1 && c <= 20) {
    return 1;
  } else {
    return 0;
  }
}

int qntbombasvizinhas(int l, int c) {
  int quantidade = 0;

  if (coordval(l - 1, c) && mat[l - 1][c].ebomba) {
    quantidade++;
  }
  if (coordval(l + 1, c) && mat[l + 1][c].ebomba) {
    quantidade++;
  }
  if (coordval(l, c - 1) && mat[l][c - 1].ebomba) {
    quantidade++;
  }
  if (coordval(l, c + 1) && mat[l][c + 1].ebomba) {
    quantidade++;
  }
  if (coordval(l + 1, c + 1) && mat[l + 1][c + 1].ebomba) {
    quantidade++;
  }
  if (coordval(l - 1, c - 1) && mat[l - 1][c - 1].ebomba) {
    quantidade++;
  }
  if (coordval(l + 1, c - 1) && mat[l + 1][c - 1].ebomba) {
    quantidade++;
  }
  if (coordval(l - 1, c + 1) && mat[l - 1][c + 1].ebomba) {
    quantidade++;
  }
  return quantidade;
}

void contbombas() {
  for (l = 1; l <= 10; l++) {
    for (c = 1; c <= 20; c++) {
      mat[l][c].vizinhos = qntbombasvizinhas(l, c);
    }
  }
}

void imprimir() {
  printf("\n\n\t  ");
  for (l = 1; l <= 20; l++) {
    if (l < 10) {
      printf("   %d", l);
    } else {
      printf("  %d", l);
    }
  }
  printf("\n\t   --------------------------------------------------------------------------------- \n");
  for (l = 1; l <= 10; l++) {
    if (l < 10) {
      printf("\t%d  |", l);
      for (c = 1; c <= 20; c++) {
        if (mat[l][c].aberta) {
          if (mat[l][c].ebomba == 1) {
            printf(" * ");
          } else {
            printf(" %d ", mat[l][c].vizinhos);
          }
        } else {
          printf("   ");
        }
        printf("|");
      }
      printf("\n\t   --------------------------------------------------------------------------------- \n");
    } else {
      printf("\t%d |", l);
      for (c = 1; c <= 20; c++) {
        if (mat[l][c].aberta) {
          if (mat[l][c].ebomba == 1) {
            printf(" * ");
          } else {
            printf(" %d ", mat[l][c].vizinhos);
          }
        } else {
          printf("   ");
        }
        printf("|");
      }
      printf("\n\t   --------------------------------------------------------------------------------- \n");
    } 
  }
}

void abrir(int l, int c) {
  if (coordval(l, c) == 1 && mat[l][c].aberta == 0) {

    mat[l][c].aberta = 1;

    if (mat[l][c].vizinhos == 0) {
      abrir(l - 1, c);
      abrir(l + 1, c);
      abrir(l, c - 1);
      abrir(l, c + 1);
      abrir(l + 1, c + 1);
      abrir(l + 1, c - 1);
      abrir(l - 1, c + 1);
      abrir(l - 1, c - 1);
    }
  }
}

int ganha() {
  int qnt = 0;

  for (l = 1; l <= 10; l++) {
    for (c = 1; c <= 20; c++) {
      if (mat[l][c].aberta == 0 && mat[l][c].ebomba == 0) {
        qnt++;
      }
    }
  }
  return qnt;
}

void dica(){
  for (l = 1; l <= 10; l++) { 
    for (c = 1; c <= 20; c++) {
      if (mat[l][c].aberta == 1) {
        if (mat[l][c].vizinhos > 0 && mat[l][c].vizinhos < 3) {
          if (coordval(l+1,c) == 1) {
             lin = l+1;
             col = c;
             cont++;
             aberta++;
            break;
          } else if (coordval(l-1,c) == 1) {
            lin = l+1;
            col = c;
            cont++;
            aberta++;
            break;
          } else if (coordval(l,c+1) == 1) {
            lin = l+1;
            col = c;
            cont++;
            aberta++;
            break;
          } else if (coordval(l,c-1) == 1) {
            lin = l+1;
            col = c;
            cont++;
            aberta++;
            break;
          } else if (coordval(l+1,c-1) == 1) {
            lin = l+1;
            col = c;
            cont++;
            aberta++;
            break;
          } else if (coordval(l-1,c+1) == 1) {
            lin = l+1;
            col = c;
            cont++;
            aberta++;
            break;
          } else if (coordval(l+1,c+1) == 1) {
            lin = l+1;
            col = c;
            cont++;
            aberta++;
            break;
          } else if (coordval(l-1,c-1) == 1) {
            lin = l+1;
            col = c;
            cont++;
            aberta++;
            break;
          } 
        }                  
      }            
    } 
    if (aberta != 0) {
      aberta = 0;
      break;
     }          
  } if (cont == 0) {
    lin = rand() % 10;
    col = rand() % 20;
    cont = 0;
  }
  printf("Eu escolheria: %d %d", lin, col);
}


void BOT() {
  int lin, col, men;
  do {
    imprimir();
    do {      
      int cont = 0, aberta = 0;
      for (l = 1; l <= 10; l++) { 
        for (c = 1; c <= 20; c++) {
          if (mat[l][c].aberta == 1) {
            if (mat[l][c].vizinhos > 0 && mat[l][c].vizinhos < 3) {
              if (coordval(l+1,c) == 1) {
                lin = l+1;
                col = c;
                cont++;
                aberta++;
                break;
              } else if (coordval(l-1,c) == 1) {
                lin = l+1;
                col = c;
                cont++;
                aberta++;
                break;
              } else if (coordval(l,c+1) == 1) {
                lin = l+1;
                col = c;
                cont++;
                aberta++;
                break;
              } else if (coordval(l,c-1) == 1) {
                lin = l+1;
                col = c;
                cont++;
                aberta++;
                break;
              } else if (coordval(l+1,c-1) == 1) {
                lin = l+1;
                col = c;
                cont++;
                aberta++;
                break;
              } else if (coordval(l-1,c+1) == 1) {
                lin = l+1;
                col = c;
                cont++;
                aberta++;
                break;
              } else if (coordval(l+1,c+1) == 1) {
                lin = l+1;
                col = c;
                cont++;
                aberta++;
                break;
              } else if (coordval(l-1,c-1) == 1) {
                lin = l+1;
                col = c;
                cont++;
                aberta++;
                break;
              } 
            }                  
          }            
        } 
        if (aberta != 0) {
          aberta = 0;
          break;
        }          
      } if (cont == 0) {
        lin = rand() % 10;
        col = rand() % 20;
        cont = 0;
      }
    } while (coordval(lin, col) == 0 || mat[lin][col].aberta == 1);
      
    abrir(lin, col);
    
  } while (ganha() != 0 && mat[lin][col].ebomba == 0);
    
  if (mat[lin][col].ebomba == 1) {
    printf("\nOLHA A BOMBA!!!");
  } else {
    printf("\nOLHA, CONSEGUIU SAIR COM AS DUAS PERNAS, VOCÊ VENCEU!");
  }
}

void jogadas() {
  int lin, col, x, z, d;

  printf("\nBem vindo ao campo minado, deseja ativar o bot? Digite 1 para sim e 0 para não ");
  scanf("%d", & x);
  
  if (x == 0) {
    printf("\nQuer ativar as dicas? Digite 1 para sim e 0 para não ");
    scanf("%d", & z);
  }
  
  if (x == 0) { //sem bot
    if (z == 0) { //sem dica
      do {
        imprimir();
        do {
          printf("\nQual a sua jogada? (Lembrando que primero a linha, depois coluna, separados por um espaço): ");
          scanf("%d %d", & lin, & col);   
          if (coordval(lin, col) == 0) {
            printf("\nEssa coordenada não pode...");
          }
        } while (coordval(lin, col) == 0 || mat[lin][col].aberta == 1);
    
        abrir(lin, col);
      } while (ganha() != 0 && mat[lin][col].ebomba == 0);
    
      if (mat[lin][col].ebomba == 1) {
        printf("\nOLHA A BOMBA!!!");
      } else {
        printf("\nOLHA, CONSEGUIU SAIR COM AS DUAS PERNAS, VOCÊ VENCEU!");
      }
    } else { //com dica
       do {
        imprimir();
        do {
          printf("\nQuer uma dica? 1 para sim 0 para não ");
          scanf("%d", & d);
          if (d == 1) {
            dica();
          }          
          printf("\nQual a sua jogada? (Lembrando que primero a linha, depois coluna, separados por um espaço): ");
          scanf("%d %d", & lin, & col);        
    
          if (coordval(lin, col) == 0) {
            printf("\nEssa coordenada não pode...");
          }
        } while (coordval(lin, col) == 0 || mat[lin][col].aberta == 1);
    
        abrir(lin, col);
      } while (ganha() != 0 && mat[lin][col].ebomba == 0);
    
      if (mat[lin][col].ebomba == 1) {
        printf("\nOLHA A BOMBA!!!");
      } else {
        printf("\nOLHA, CONSEGUIU SAIR COM AS DUAS PERNAS, VOCÊ VENCEU!");
      }
    } 
  } else { //com bot
    BOT();
  }
}