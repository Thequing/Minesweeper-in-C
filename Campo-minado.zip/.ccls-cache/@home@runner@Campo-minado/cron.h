#ifndef head
#define cron

typedef struct relogio {
int seg;
int mins;
int horas;
} cronometro;

void func_cronometro (cronometro tempo, int estado_jogo);

void crono (int estado_jogo);

#endif