#include <stdio.h>

#include <stdlib.h>

#include <time.h>

typedef struct {
  int ebomba;
  int aberta;
  int vizinhos;
}
campo;

campo mat[10][20];
int l, c;

int coordval(int l, int c) {
  if (l >= 1 && l <= 10 && c >= 1 && c <= 20) {
    return 1;
  } else {
    return 0;
  }
}

int qntbombasvizinhas(int l, int c) {
  int quantidade = 0;

  if (coordval(l - 1, c) && mat[l - 1][c].ebomba) {
    quantidade++;
  }
  if (coordval(l + 1, c) && mat[l + 1][c].ebomba) {
    quantidade++;
  }
  if (coordval(l, c - 1) && mat[l][c - 1].ebomba) {
    quantidade++;
  }
  if (coordval(l, c + 1) && mat[l][c + 1].ebomba) {
    quantidade++;
  }
  if (coordval(l + 1, c + 1) && mat[l + 1][c + 1].ebomba) {
    quantidade++;
  }
  if (coordval(l - 1, c - 1) && mat[l - 1][c - 1].ebomba) {
    quantidade++;
  }
  if (coordval(l + 1, c - 1) && mat[l + 1][c - 1].ebomba) {
    quantidade++;
  }
  if (coordval(l - 1, c + 1) && mat[l - 1][c + 1].ebomba) {
    quantidade++;
  }
  return quantidade;
}

void contbombas() {
  for (l = 1; l <= 10; l++) {
    for (c = 1; c <= 20; c++) {
      mat[l][c].vizinhos = qntbombasvizinhas(l, c);
    }
  }
}