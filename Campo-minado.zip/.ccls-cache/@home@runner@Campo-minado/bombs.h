#ifndef bombs

#define bombs

int coordval(int l, int c);

int qntbombasvizinhas(int l, int c);

void contbombas();

#endif