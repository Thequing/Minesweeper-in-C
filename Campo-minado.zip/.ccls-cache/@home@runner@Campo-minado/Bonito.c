#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
  int ebomba;
  int estaaberta;
  int vizinhos;
}celula;

celula jogo[10][20];
int l, c;

void inicializarjogo();

void sortearbombas(int n);

int coordenadaevalida(int l, int c);

int qntbombasvizinhas(int l, int c);

void contarbombas();

void imprimir();

void abrir(int l, int c);

int ganha();

void jogadas();

int main(void) {

  inicializarjogo();
  sortearbombas(40);
  contarbombas();
  jogadas();

  return 0;
}

void inicializarjogo() {
  for (l = 0; l < 10; l++) {
    for (c = 0; c < 20; c++) {
      jogo[l][c].ebomba = 0;
      jogo[l][c].estaaberta = 0;
      jogo[l][c].vizinhos = 0;
    }
  }
}

void sortearbombas(int n) {
  int i;
  srand(time(NULL));
  for (i = l; i <= n; i++) {
    l = rand() % 10;
    c = rand() % 20;
    if (jogo[l][c].ebomba == 0) {
      jogo[l][c].ebomba = 1;
    } else {
      i--;
    }
  }
}

int coordenadaevalida(int l, int c) {
  if (l >= 0 && l < 10 && c >= 0 && c < 20) {
    return 1;
  } else {
    return 0;
  }
}

int qntbombasvizinhas(int l, int c) {
  int quantidade = 0;

  if (coordenadaevalida(l - 1, c) && jogo[l - 1][c].ebomba) {
    quantidade++;
  }
  if (coordenadaevalida(l + 1, c) && jogo[l + 1][c].ebomba) {
    quantidade++;
  }
  if (coordenadaevalida(l, c - 1) && jogo[l][c - 1].ebomba) {
    quantidade++;
  }
  if (coordenadaevalida(l, c + 1) && jogo[l][c + 1].ebomba) {
    quantidade++;
  }
  if (coordenadaevalida(l + 1, c + 1) && jogo[l + 1][c + 1].ebomba) {
    quantidade++;
  }
  if (coordenadaevalida(l - 1, c - 1) && jogo[l - 1][c - 1].ebomba) {
    quantidade++;
  }
  if (coordenadaevalida(l + 1, c - 1) && jogo[l + 1][c - 1].ebomba) {
    quantidade++;
  }
  if (coordenadaevalida(l - 1, c + 1) && jogo[l - 1][c + 1].ebomba) {
    quantidade++;
  }
  return quantidade;
}

void contarbombas() {
  for (l = 0; l < 10; l++) {
    for (c = 0; c < 20; c++) {
      jogo[l][c].vizinhos = qntbombasvizinhas(l, c);
    }
  }
}

void imprimir() {
  printf("\n\n\t  ");
  for (l = 0; l < 20; l++) {
    printf(" %d ", l);
  }
  printf("\n\t  --------------------------------------------------------------------------------- \n");
  for (l = 0; l < 10; l++) {
    printf("\t%d |", l);
    for (c = 0; c < 20; c++) {
      if (jogo[l][c].estaaberta) {
        if (jogo[l][c].ebomba == 1) {
          printf(" * ");
        } else {
          printf(" %d ", jogo[l][c].vizinhos);
        }
      } else {
        printf("   ");
      }
      printf("|");
    }
    printf("\n\t  --------------------------------------------------------------------------------- \n");
  }
}

void abrir(int l, int c) {
  if (coordenadaevalida(l, c) == 1 && jogo[l][c].estaaberta == 0) {

    jogo[l][c].estaaberta = 1;

    if (jogo[l][c].vizinhos == 0) {
      abrir(l - 1, c);
      abrir(l + 1, c);
      abrir(l, c - 1);
      abrir(l, c + 1);
      abrir(l + 1, c + 1);
      abrir(l + 1, c - 1);
      abrir(l - 1, c + 1);
      abrir(l - 1, c - 1);
    }
  }
}

int ganhou() {
  int quantidade = 0;

  for (l = 0; l < 10; l++) {
    for (c = 0; c < 20; c++) {
      if (jogo[l][c].estaaberta == 0 && jogo[l][c].ebomba == 0) {
        quantidade++;
      }
    }
  }
  return quantidade;
}

void jogadas() {
  int lin, col;

  do {
    imprimir();
    do {
      printf("\nqual a sua jogada: ");
      scanf("%d %d", & lin, & col);

      if (coordenadaevalida(lin, col) == 0) {
        printf("\nEssa coordenada não pode...");
      }
    } while (coordenadaevalida(lin, col) == 0 || jogo[lin][col].estaaberta == 1);

    abrir(lin, col);
  } while (ganhou() != 0 && jogo[lin][col].ebomba == 0);

  if (jogo[lin][col].ebomba == 1) {
    printf("\nOLHA A BOMBA!!!");
  } else {
    printf("\nOLHA, CONSEGUIU SAIR COM AS DUAS PERNAS, VOCÊ VENCEU!");
  }
}